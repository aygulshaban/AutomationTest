package com.uni.exam.automation.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

	public class ConverterPage extends HomePage<ConverterPage> {
	
	private WebDriver driver;
	
	public ConverterPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	public ConvertLengthPage navaigateToConvertLength() {
		driver.navigate().to(BASE_URL+"1/merki_daljina.html");
		return new ConvertLengthPage(driver);
	}


}
