package com.uni.exam.automation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.openqa.selenium.chrome.ChromeDriver;

import com.uni.exam.automation.Pages.HomePage;

import io.github.bonigarcia.seljup.SeleniumExtension;

@ExtendWith(SeleniumExtension.class)
public class ConvertLengthPageTest {
	
	@Test
	public void convertLenghtMiKm(ChromeDriver driver) throws InterruptedException {
		
		driver.manage().window().maximize();
		
		new HomePage(driver)
		.navigateToConverterPage()
		.navaigateToConvertLength().enterValue("1")
		.countLengthMiKm();
	}
	
	@Test
	public void convertLenghtKmMi(ChromeDriver driver) throws InterruptedException {
		
		driver.manage().window().maximize();
		
		new HomePage(driver)
		.navigateToConverterPage()
		.navaigateToConvertLength().enterValue("1")
		.countLengthKmMi();
	}
	
	@Test
	public void convertLenghtWithoutValue(ChromeDriver driver) throws InterruptedException {
		
		driver.manage().window().maximize();
		
		new HomePage(driver)
		.navigateToConverterPage()
		.navaigateToConvertLength().enterValue("")
		.countLengthMiKm();
	}
	
	@Test
	public void clickClearBtn(ChromeDriver driver) throws InterruptedException {
		
		driver.manage().window().maximize();
		
		new HomePage(driver)
		.navigateToConverterPage()
		.navaigateToConvertLength().enterValue("1")
		.clickOnClear();
	}
	
	@Test
	public void convertLenghtWithoutChangeMeasuringUnits(ChromeDriver driver) throws InterruptedException {
		
		driver.manage().window().maximize();
		
		new HomePage(driver)
		.navigateToConverterPage()
		.navaigateToConvertLength().enterValue("1")
		.clickOnCount();
	}


}
