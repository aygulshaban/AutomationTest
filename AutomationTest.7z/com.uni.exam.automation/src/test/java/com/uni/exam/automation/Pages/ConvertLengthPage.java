package com.uni.exam.automation.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

	public class ConvertLengthPage extends ConverterPage {
	
		private WebDriver driver;
	
		@FindBy(id = "suma")
		private WebElement valueInputText;
		
		@FindBy(id = "ot")
		private WebElement otCombobox;
		
		@FindBy(id = "kam")
		private WebElement kamCombobox;
		
		@FindBy(className = "presmetni_b")
		private WebElement presmetniBtn;
		
		@FindBy(className = "izchisti_b")
		private WebElement izchistiBtn;
	
	
	public ConvertLengthPage(WebDriver driver) {
		super(driver);
		PageFactory.initElements(driver, this);
		this.driver = driver;
}
	
	public ConvertLengthPage enterValue(String value) {
		valueInputText.sendKeys(value);
		return this;
	}
	
	
	public void countLengthMiKm() throws InterruptedException {
		
		Select otCb = new Select(otCombobox);
	    otCb.selectByValue("6.2137119223733396961743418436332e-4");
	    Thread.sleep(2000);
	    
	    Select kamCb = new Select(kamCombobox);
	    kamCb.selectByValue("0.001");
	    Thread.sleep(1000);
	    
	    clickOnCount();
	}
	
	public void countLengthKmMi() throws InterruptedException {
		
		Select otCb = new Select(otCombobox);
	    otCb.selectByValue("0.001");
	    Thread.sleep(2000);
	    
	    Select kamCb = new Select(kamCombobox);
	    kamCb.selectByValue("6.2137119223733396961743418436332e-4");
	    Thread.sleep(2000);
	    
	    clickOnCount();
	    
	}
	
	public ConvertLengthPage clickOnCount() throws InterruptedException {
		presmetniBtn.click();
		Thread.sleep(2000);
		return this;
	}
	
	public ConvertLengthPage clickOnClear() throws InterruptedException {
		izchistiBtn.click();
		Thread.sleep(2000);
		return this;
	}

}
