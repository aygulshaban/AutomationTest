package com.uni.exam.automation.Pages;

import org.openqa.selenium.WebDriver;

public class HomePage<T> extends BasePage<HomePage> {
	
private WebDriver driver;
	
	public HomePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
	
	public ConverterPage navigateToConverterPage() {
		driver.navigate().to(BASE_URL + "2/konvertor.html");
		return  new ConverterPage(driver);
	}



}
